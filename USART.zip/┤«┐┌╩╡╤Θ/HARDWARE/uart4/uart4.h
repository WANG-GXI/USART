#ifndef UART4_H
#define UART4_H
#include "sys.h"

void uart4_Init(void);
void uart4_SendByte(unsigned char *DataToSend ,u8 data_num);
void USART1_Puts(char * str);
extern  u8 com1_data;
void UART4_SendString(char* s);
void UART4_Send_Command(char* s);
u8 UART4_Send_AT_Command_End(char *b,char *a,u8 wait_time,u32 interval_time);

#endif

